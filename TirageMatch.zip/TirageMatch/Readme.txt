

                             UNIVERSITE INUKA 
                    3 eme Annee Sciences Informatiques
                                 MEDIAN    

                         LISTE DES PARTICIPANTS

               NOM                   PRENOM                    CODE

     1-    JEAN BAPTISTE             LENS                      32220
     2-    BERGER                    Nerls                     31853
     3-    PIERRE                    MICHENKA                  31545





