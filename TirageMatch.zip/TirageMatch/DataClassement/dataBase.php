<?php
// gestion des scores pour le premier equipe Groupe A
$_SESSION['equipeUnGroupeA']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0,
    "points"=>0
];

// gestion des scores pour la deuxieme equipes groupe A
$_SESSION['equipeDeuxGroupeA']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];

// gestion des scores pour la troisieme equipes groupe A
$_SESSION['equipeTroisGroupeA']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];

// gestion des scores pour la quatrieme equipes groupe A
$_SESSION['equipeQuatreGroupeA']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];
// pour les equipes du Groupes B 

// gestion des scores pour le premier equipes groupe B
$_SESSION['equipeUnGroupeB']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];
// ................................... 

// gestion des scores pour la deuxieme equipes groupe B
$_SESSION['equipeDeuxGroupeB']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];
// gestion des scores pour la troisieme equipes groupe A

$_SESSION['equipeTroisGroupeB']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];

// gestion des scores pour la Quatrieme equipes groupe B
$_SESSION['equipeQuatreGroupeB']=[
    "nomEquipe"=>"",
    "scores"=>["","",""],
    "matchJoue"=>0,
    "matchGagne"=>0,
    "matchNul"=>0,
    "matchPerdu"=>0,
    "butPour"=>0,
    "butContre"=>0, 
    "difference"=>0, 
    "points"=>0
];
?>